var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');


var UserJobSchema = new mongoose.Schema({
    UserID: Number,
    jobName: String,
    rsvp: String,
    categoryName: String
});

var UserJobdb = mongoose.model('userjobs', UserJobSchema);
module.exports = UserJobdb;

