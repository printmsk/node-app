var UserJob = require('../models/UserJob')

class UserProfile {

    constructor(UserID, UserJobs) {
        this._UserID = UserID;
        this._UserJobs = UserJobs;
    };

    get UserID() {
        return this._UserID;
    }
    set UserID(value) {
        this._UserID = value;
    }

    get UserJobs() {
        return this._UserJobs;
    }
    set UserJobs(value) {
        this._UserJobs = value;
    }

    

    getJobs() {
        return this._UserJobs;
    }
 
   addJob(userJob){
   var jobs = this._UserJobs;
   var count=0,n = jobs.length;
   if(n>0){//checking for no saved jobs
   for (let i = 0; i < n; i++) {
       if(jobs[i].jobName!=userJob.jobName){
         count++;
         if(count==n){
            jobs.push(userJob);
         }
       }

   }
}
else{
   jobs.push(userJob);
}
  this._UserJobs=jobs;

}

    updateJob(jobName, rsvp, categoryName) {
        var jobs = this._UserJobs;
        for (let i = 0; i < jobs.length; i++) {
            if (jobs[i].jobName == jobName) {
                if (jobs[i].rsvp != rsvp) {
                    var userJob = new UserJob(jobs[i].jobName, rsvp, categoryName);
                    jobs.splice(i, 1, userJob);
                }
            }
        }
        this._UserJobs = jobs;
    }

    removeJob(userJob) {
        console.log("comming to remove" + userJob);
        var jobs = this._UserJobs;
        console.log(jobs);
        for (let i = 0; i < jobs.length; i++) {
            if (jobs[i].jobName == userJob.jobName ) {
                jobs.splice(i, 1);
            }
        }
        this._UserJobs = jobs;
    }

    emptyProfile() {
        this.UserJobs=null;
    }
    convert(obj) {
        Object.assign(this, obj);
    }
}
/*var UserJob1 = new UserJob(
    Job.getJob(1).jobName,
    rsvp = "No",
    Job.getJob(2).categoryName,
)
var UserJob2 = new UserJob(
    Job.getJob(2).jobName,
    rsvp = "No",
    Job.getJob(2).categoryName,
)

var userJobs = [UserJob1, UserJob2];
var user1 = users.getUsers[0];
console.log(user1);
module.exports.UserProfile1 = new UserProfile(user1.UserID, userJobs);*/
module.exports = UserProfile;