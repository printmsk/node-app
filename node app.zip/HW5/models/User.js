var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');
const passportMongoose = require('passport-local-mongoose');


var userSchema = new mongoose.Schema({
    UserID: Number,
    firstName: String,
    lastName: String,
    username: String,
    password: String,
    address1Field: String,
    address2Field: String,
    city: String,
    state: String,
    zipcode: Number,
    country: String
});
userSchema.plugin(passportMongoose);
module.exports.userDB = mongoose.model('userdetails', userSchema);
