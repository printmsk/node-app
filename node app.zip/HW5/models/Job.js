var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');

var jobSchema = new mongoose.Schema({
    jobId: Number,
    jobName: String,
    categoryName: String,
    details: String,
    dateTime: String,
    imageURL: String,
    userId:Number,
});

var jobDB = mongoose.model('jobs', jobSchema);
module.exports = jobDB;