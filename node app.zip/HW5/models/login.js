var mongoose= require('mongoose');
mongoose.connect('mongodb://localhost/milestone4', {useNewUrlParser:true});

var loginSchema= new mongoose.Schema({
    ucode:Number,
    username:String,
    password:String
});

var logindb=mongoose.model('logins', loginSchema );
module.exports=logindb;