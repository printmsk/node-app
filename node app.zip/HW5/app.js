var express = require("express");
var app = express();
var session = require('express-session');
var profileController = require('./routes/profileController');
var path = require('path');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');
app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));
app.use("/partials", express.static("partials"));
app.use(session({ secret: 'msk', resave: false, saveUninitialized: true }));

app.use('/', profileController);
app.use('*', profileController);



app.listen(3000);
console.log("Started: Listening at 3000");

  module.exports = app;