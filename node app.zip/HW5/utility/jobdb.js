var Job = require('../models/Job');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');
mongoose.Promise = global.Promise;


module.exports.getJobs = function () {
    var docs = Job.find();
    return docs;
}

module.exports.getCategory = function () {
    var cats = Job.distinct("categoryName");
    return cats;
}

module.exports.getConnection = function (id) {
    var jobId = Job.find({ "jobId": id });
    return jobId;
}

module.exports.getJobByName = function (name) {
    var job1 = Job.find({ "jobName": name } )
    console.log("job1 is");
    console.log(job1);
    return job1; 
}

module.exports.getSize = function () {
    var size = Job.count();
    return size;
}

/* module.exports.getJobs = function () {

    let jobs = [];
    for (let i = 0; i < data.length; i++) {
        let job = new Job(
            data[i].jobId,
            data[i].jobName,
            data[i].categoryName,
            data[i].details,
            data[i].dateTime,
            data[i].imageURL);
        //console.log("object model readen correctly")

        jobs.push(job);
        //adding jobs into list
        //console.log("all jobs retrived successfully")
    }
    return jobs;


};// function exporting list of jobs to navigate


module.exports.getJob = function (jobId) {//using jobId to extract info abt spec job
    for (var i = 0; i < data.length; i++) {
        if (parseInt(data[i].jobId) == jobId) {

            let job = new Job(data[i].jobId,
                data[i].jobName,

                data[i].categoryName,

                data[i].details,

                data[i].dateTime,

                data[i].imageURL
            )

            return job;
        }

    }
};

module.exports.getJobByName = function (jobName) {
    for (var i = 0; i < data.length; i++) {
        if (data[i].jobName == jobName) {
            let job = new Job(data[i].jobId,
                data[i].jobName,

                data[i].categoryName,

                data[i].details,

                data[i].dateTime,

                data[i].imageURL
            )
            return job;

        }
    }
}
*/



//creating hardcoded dataset for job_details
/*var data = [
    {
        jobId: 1,
        jobName: "Front end developer at spec communications",
        categoryName: "Internship",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime: "Thursday sep 20,2019",
        imageURL: "/assets/Front-End-Development-Bundle.jpg"

    },
    {
        jobId: 2,
        jobName: "Back end developer at coocle",
        categoryName: "Internship",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime: "Friday sep 21,2019",
        imageURL: "/assets/back-end-developer.jpg"
    },
    {
        jobId: 3,
        jobName: "ios developer at Orange",
        categoryName: "Internship",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime: "Sunday sep 20, 2019",
        imageURL: "/assets/iOSDeveloper.jpg"
    },
    {
        jobId: 4,
        jobName: "UI front end developer at casper",
        categoryName: "Full-time",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime: "Monday sep 20,2019",
        imageURL: "/assets/UIDEVeloper.jpg"
    },
    {
        jobId: 5,
        jobName: "senior Java developer at Jdoodle",
        categoryName: "Full-time",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime:"Thursday sep 20, 2019",
        imageURL: "/assets/seniorjava.jpg"
    },
    {
        jobId: 6,
        jobName: "Junior Java developer at ex_scripts",
        categoryName: "Full-time",
        details: "We are looking for a candidate with strong Angular experience developing web applications. A candidate with additional experience developing C# applications as well hosting web applications in Microsoft Azure would be a plus",
        dateTime:"Thursday sep 20, 2019",
        imageURL: "/assets/java.jpg"
    },

];

module.exports.getSize = function () {

    return data.length;
}*/
