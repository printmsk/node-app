var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/milestone4');
mongoose.Promise = global.Promise;
var bcrypt = require('bcryptjs');
var UserJob = require("../models/UserJob");
var loginDetails = require("../models/login");
var dataobj = require("../models/Job");
var user = require('../models/User');

module.exports.getUsers = function () {
    var usr = user.userDB.find();
    console.log("usr is");
    console.log(usr);
    return usr;
}
module.exports.getUserJobs = function () {
    var userjobs = UserJob.find();
    console.log('user jobs are');
    console.log(userjobs);
    return userjobs;
}
module.exports.getUser = function (id) {
    console.log("in get user");
    var usr = null;
    user.find({ 'userID': id }, function (err, data) {
        if (err) {
            throw err;
        }
        else {
            usr = data;
        }
    });
    return usr;
}
module.exports.getLoginDetails = function (uname) {
    var loginDetails1 = user.userDB.find({ username: uname });
    console.log('loginDetails1');
    console.log(loginDetails1);
    return loginDetails1
}


module.exports.getJobWithName = function (name) {
    var jobnames = dataobj.find({ jobName: name })
    return jobnames;
}
module.exports.getUserJobsWithCode = function (ucode) {
    var jobNameWcode = UserJob.find({ UserID: ucode })
    return jobNameWcode;
}



module.exports.getNamewithCode = function (uscode) {
    var username = User.userDB.find({ UserID: uscode })
    return username;

}

var userCredentials = [];

loginDetails.find().exec(function (err, docs) {
    for (var i = 0; i < docs.length; i++) {
        var ob = { ucode: docs[i].ucode, username: docs[i].username, password: docs[i].password }
        userCredentials.push(ob);
    }
});
console.log(userCredentials);

module.exports.hashPassword = function () {
    var hashPass = []
    for (var i = 0; i < userCredentials.length; i++) {
        let hash = bcrypt.hashSync(userCredentials[i].password, 10)
        var obj = { ucode: userCredentials[i].ucode, username: userCredentials[i].username, password: hash }
        hashPass.push(obj)
    }
    loginDetails.countDocuments().exec(function (err, docs) {
        if (docs == 0) {
            loginDetails.insertMany(hashPass, function (err) {
                if (err) {
                    console.log("Insert only unique values")
                }
            });
        }
    })
    return hashPass
}