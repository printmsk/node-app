var express = require('express');
var router = express.Router();
var bodyparser = require('body-parser');
var UserProfileModel = require('../utility/userdb');
var UserJob = require('../models/UserJob');
var urlencoded = bodyparser.urlencoded({ extended: false });
var bcrypt = require('bcryptjs');
const { check, validationResult } = require('express-validator');
var obj = require('../utility/jobdb');
var job1=require('../models/Job')
var mongoose = require('mongoose');
var userdetails = require('../models/User');
const passport = require('passport');
mongoose.connect('mongodb://localhost/milestone4');
mongoose.Promise = global.Promise;

var loggedIn = false;

router.get('/jobs', function (req, res) {/*---------jobs page displays all jobs-----*/
    obj.getJobs().exec(function (err, data) {
        if (err) throw err
        console.log("data is:" + data);
        obj.getCategory().exec(function (err, category) {
            if (err) throw err
            console.log("category is:" + category);
            res.render('jobs', { data: data, category: category, isLoggedIn: loggedIn, user: req.session.theUser });
        })
    })
});

router.get('/signup', function (req, res) {/*-------------new users can register here -----*/
    res.render('register', { isLoggedIn: loggedIn, user: req.session.theUser, error: undefined, err: undefined, user: req.session.theUser });
})

router.post('/register', urlencoded, [check('UserID').isNumeric().withMessage('userID must be numeric'),
    check('firstName').isAlpha().withMessage('firstName must be alphabetical'),
    check('lastName').isAlpha().withMessage('lastName must be alphabetical'),
    check('username').isEmail().withMessage('username must be email'),
    check('zipcode').isNumeric().withMessage('zipcode must be numeric'),
    check('password').isLength({ min: 5 }).withMessage('password must be length of 5')], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            console.log(errors);
            res.render('register', { isLoggedIn: loggedIn, error: errors.array(), err: undefined, user: req.session.theUser });
        }
        else {
            var newUser = new userdetails.userDB({
                UserID: req.body.UserID,
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                username: req.body.username,
                password: req.body.password,
                address1Field: req.body.address1Field,
                address2Field: req.body.address2Field,
                city: req.body.city,
                state: req.body.state,
                zipcode: req.body.zipcode,
                country: req.body.country
            });
            console.log(newUser);
            userdetails.userDB.register(newUser, req.body.password, function (err, user) {
                if (err) {
                    console.log(err)
                    return res.render("register", { isLoggedIn: loggedIn, user: req.session.theUser, error: errors.array(), err: undefined, user: req.session.theUser });
                }
                passport.authenticate("local")(req, res, function () {
                    res.redirect("/");
                });
            });
        }   
})
router.get('/signin', function (req, res) {//signin page
    if (!loggedIn) {
        res.render('login', { isLoggedIn: loggedIn, err: "", error: undefined, user: req.session.theUser });
    }
    res.redirect('/myjobs');
});

router.post('/login', urlencoded, [/*----already regitered users can be login here diiferent conditions generate different errors if there is no error user can login and redirect to saved jobs page------*/
    check('email').isEmail().withMessage('email mustbe used as username'),
    check('password').isLength({ min: 5, max: 100 })
        .withMessage('Password must be minimum 5 characters long and max 100 ')], function (req, res) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            console.log(errors);
            res.render('login', { isLoggedIn: loggedIn, error: errors.array(), err: undefined, user: req.session.theUser });
        }
        else {
            var username = req.body.email;
            var password = req.body.password;
            var saltrounds = 10;
            UserProfileModel.getLoginDetails(username).exec(function (err, docs) {
                console.log(docs)
                if (docs.length == 0) {
                    res.render('login', { isLoggedIn: loggedIn, err: "Invalid Username/Password", error: undefined, user: req.session.theUser });
                }
                else {
                    console.log('here it is');
                    console.log(docs[0]);
                    var hash = bcrypt.hashSync(docs[0].password, saltrounds);//generating hash for password
                    var phash = bcrypt.compareSync(password, hash);//comapring password against hash
                    if (phash == true) {
                        UserID = (docs[0].UserID);
                        req.session.theUser = docs[0];//if login attempt was successful store the the user details in session
                        req.session.userId = UserID;
                        console.log(req.session.userId);
                        loggedIn = true;
                        res.redirect('/myjobs')// if login credentials are valid the user will be signed in and redirected directly to his saved jobs page
                    }
                    else {
                        res.render('login', { isLoggedIn: loggedIn, err: 'invlaid password', error: undefined, user: req.session.theUser });
                    }
                }
            })
        }
});

router.get('/myjobs', function (req, res) {//myjobs page(saved connections) page retrives jobs based on loggedin user
  
    if (!loggedIn) {
        res.render('info', { isLoggedIn: loggedIn});
        }
    else {
        console.log(" reached else here" + loggedIn);
        UserProfileModel.getUsers().exec(function (err, res1) {
            if (err) {
                console.log('err');
                throw err;
            }
            console.log("req.session.userId")
            console.log(req.session.userId);
        })
        UserProfileModel.getUserJobsWithCode(req.session.userId).exec(function (err, result) {//gets userjobs based on the userId
            if (err) throw err;
            console.log("we r here in");
            console.log(result);
            
            console.log(loggedIn);
            res.render('myjobs', { data: result, isLoggedIn: loggedIn, user: req.session.theUser });
        })


    }
});
router.get('/editjob', function (req, res) {//edit job page where the user able to edit the already posted job
    console.log('jobName is:' + req.session.jobName);
    if (loggedIn) res.render('editjob', { isLoggedIn: loggedIn, error: undefined, jobName: req.session.jobName, user: req.session.theUser })
    else res.render('info', { isLoggedIn: loggedIn, jobName: req.session.jobName, user: req.session.theUser});
})
router.post('/added', urlencoded, [check('categoryName').isIn(['Internship', 'Full-time']).withMessage('categoryName must be "intership" or "fulltime"'),
check('dateTime').isNumeric().withMessage('dateTime must be numberical value')], function (req, res) {
        var task = req.body.action1;
        
    switch (task) {
        case "delete":
            if (loggedIn) {
                var delitem = req.body.jobName;
                job1.deleteOne({ jobName: delitem }).exec(function (err, result) {
                    if (err) throw err;
                })
                UserJob.deleteMany({ jobName: delitem }).exec(function (err, result) {
                    if (err) throw err;
                })
                res.redirect('/jobs');
            }
            break;
        case "navigate":
            if (loggedIn) {
                console.log('req.session.jobName :' + req.session.jobName);
                res.redirect('/editjob');
            }
            break;
        case "edit":
            const errors = validationResult(req);
            console.log(errors);
            console.log(errors.mapped());
            if (!errors.isEmpty()) {
                res.render('editjob', { isLoggedIn: loggedIn, error: errors.array(), jobName: req.session.jobName, user: req.session.theUser });
            }
            else if (loggedIn) {

                job1.findOneAndUpdate({//filter jobs based on userId and jobName and update response of category,details and datetime of a job
                    userId: req.session.userId,
                    jobName: req.session.jobName,
                },
                    {
                        categoryName: req.body.categoryName,
                        details: req.body.details,
                        dateTime: req.body.dateTime,
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    });
                res.redirect('/jobs');
            }
            else {
                res.redirect('/jobs')
            }
            break;
    }
});
router.post('/myjobs', urlencoded, function (req, res) {// myjobs page where the logged in user is able to delete or update the rsvp of saved jobs
    var task = req.body.action;

    switch (task) {
        case "delete":
            if (loggedIn) {
                var act = req.body.actionOp;
                var delitem = req.body.jobName;
                UserJob.deleteOne({ jobName: delitem }).exec(function (err, result) {
                    if (err) throw err;
                })
                res.redirect('/myjobs')
            }

            break;
        case "update":

            if (loggedIn) {
                UserJob.findOneAndUpdate({//filter userjobs based on userId and jobName 
                    UserID: req.session.userId,
                    jobName: req.body.jobName,
                },
                    {
                        jobName: req.body.jobName,
                        rsvp: req.body.rsvp,
                        categoryName: req.body.categoryName,
                    },
                    { upsert: true, returnNewDocument: true }).exec(function (err, docs) {
                        if (err) throw err;
                        console.log(docs);
                    });
                res.redirect('/myjobs');
            }
            else {
                res.redirect('/myjobs')
            }
            break;

    }
});
router.get('/newapplication', function (req, res) {//posting a new job(connection)
    if (loggedIn) {
        loggedIn = true;
        res.render('newapplication', { isLoggedIn: loggedIn, error: undefined, user: req.session.theUser });
    }
    else {
        res.render('signing', { isLoggedIn: loggedIn, user: req.session.theUser });
    }
});

router.get('/signout', function (req, res) {//signout page
    loggedIn = false;
    req.session.destroy();
    res.render('index', { isLoggedIn: loggedIn, user:'' });
});

router.get('/', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn, user: req.session.theUser });
});

router.get('/index', function (req, res) {
    res.render('index', { isLoggedIn: loggedIn, user: req.session.theUser });
});

router.get('/Job_detail/:jobName', function (req, res) {

    var job = obj.getJobByName(req.params.jobName).exec(function (err, data1) {
        if (err) throw err
        console.log('data1 is:');
        console.log(data1);
        req.session.jobName = data1[0].jobName;
        res.render('job_detail', { data: data1, isLoggedIn: loggedIn, userIdNo: req.session.userId, user: req.session.theUser});
    })
    
})

router.get('/contact', function (req, res) {
    res.render('contact', { isLoggedIn: loggedIn, user: req.session.theUser });
});

router.get('/about', function (req, res) {
    res.render('about', { isLoggedIn: loggedIn, user: req.session.theUser });
});

router.post('/newjob', urlencoded, [check('jobId').isNumeric().withMessage('jobid must be a number'),
    check('jobName').isLength({min:3}).withMessage('jobName must be length of 3'),
    check('categoryName').isIn(['Internship','Full-time']).withMessage('categoryName must be "intership" or "fulltime"'),
    check('dateTime').isNumeric().withMessage('dateTime must be numberical value')], function (req, res) {
        const errors = validationResult(req);
        console.log(errors);
        console.log(errors.mapped());
        if (!errors.isEmpty()) {
            res.render('newapplication', { isLoggedIn: loggedIn, error: errors.array(), user: req.session.theUser });
        }
        else {
            console.log("session user :"+req.session.userId);
            var newjob = [{ userId: req.session.userId, jobName: req.body.jobName, jobId: req.body.jobId, details: req.body.details, dateTime: req.body.dateTime, imageURL: req.body.imageURL, categoryName: req.body.categoryName }];
            job1.find({ jobName: req.body.jobName, categoryName: req.body.categoryName }).exec(function (err, docs) {
                if (err) throw err;

                if (docs.length == 0) {
                    job1.insertMany(newjob, function (err, docs) {
                        if (err) throw err;
                    })
                }

            })
        }
    res.redirect('/jobs');
});




router.get("*", function (req, res) {
    res.render('index', { isLoggedIn: loggedIn, user: req.session.theUser.firstName });
});


module.exports = router;